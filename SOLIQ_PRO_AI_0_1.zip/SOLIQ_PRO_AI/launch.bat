@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Birinchi ishga tushirish. Virtual muhit yaratilmoqda...
  python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m streamlit run app.py
pause
